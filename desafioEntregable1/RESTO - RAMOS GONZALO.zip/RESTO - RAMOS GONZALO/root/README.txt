Buenos dias. Soy Gonzalo Ramos y adjunto mi proyecto para un Restaurante. El lugar no existe realmente, por eso quiero
aclarar que las imagenes, direcciones y el <iframe> de Google Maps son de lugares distintos. Estos puntos que mencione
deberian ser modificados para adaptarse al posible proyecto real para una PYME real.