Buenos dias. Soy Gonzalo Ramos y estos son mis wireframes de mi proyecto en formato PDF y BMPR. Quiero destacar que
probablemente algunas páginas del sitio las modificare en proximas clases a medida que se avance con lo aprendido
asi que si hay alguna diferencia leve entre el proyecto y el wireframe es por eso.